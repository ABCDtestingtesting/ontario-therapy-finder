import unittest
from google_auto import parse_browser_result,normalize_links,MapsIncomplete,MapsBlocked,listing_key
class Tests(unittest.TestCase):
 def test_dedup_coordinates_and_reject_outside(self):
  center=(43.7,-79.8)
  links=[{'url':'https://www.google.com/maps/place/ABC/data=!3d43.7100!4d-79.8100','name':'Office A'},
         {'url':'https://www.google.com/maps/place/ABC/data=!3d43.7100!4d-79.8100','name':'Office A'},
         {'url':'https://www.google.com/maps/place/X/data=!3d44.7100!4d-79.8100','name':'Office X'}]
  got=normalize_links(links,center)
  self.assertEqual(len(got['places']),1)
  self.assertEqual(got['outside_radius'],1)
 def test_incomplete_never_zero(self):
  with self.assertRaises(MapsIncomplete):parse_browser_result('N4G',(42.8,-80.7),{'completed':False,'place_links':[]})
 def test_no_results_possible_only_with_proven_end(self):
  x=parse_browser_result('N4G',(42.8,-80.7),{'completed':True,'completion_reason':'explicit_no_results','place_links':[]})
  self.assertEqual(x['observed_5km'],0)
 def test_120_limit_is_lower_bound(self):
  links=[{'name':f'Office {i}','coordinates':(43.7,-79.8),'url':f'https://google.com/maps/place/x{i}'} for i in range(120)]
  x=parse_browser_result('L7A',(43.7,-79.8),{'completed':True,'place_links':links})
  self.assertTrue(x['capped']);self.assertEqual(x['coverage'],'capped_lower_bound')
 def test_missing_coordinates_flagged(self):
  x=parse_browser_result('N4G',(42.8,-80.7),{'completed':True,'place_links':[{'name':'Therapy','url':'https://www.google.com/maps/place/Therapy'}]})
  self.assertEqual(x['coverage'],'unresolved_location_links')
 def test_access_is_not_zero(self):
  with self.assertRaises(MapsBlocked):parse_browser_result('N4G',(42.8,-80.7),{'blocked':True,'place_links':[]})
if __name__=='__main__':unittest.main()

class DecisionTests(unittest.TestCase):
 def test_crowded_maps_area_needs_one_query(self):
  import tempfile,google_auto
  from pathlib import Path
  from unittest.mock import patch
  class C:
   def close(self):pass
  class P:
   def __enter__(self):return self
   def __exit__(self,*a):pass
  calls=[]
  def fake(ctx,code,city,center,folder,query):
   calls.append(query)
   return {'observed_5km':25,'missing_coordinates':0,'capped':False,
       'places':[{'name':'ABC','coordinates':(43,-80),'url':'https://example.test'}],
       'source_url':'https://example.test'}
  with tempfile.TemporaryDirectory() as tmp:
   with patch.object(google_auto,'sync_playwright',lambda:P()),\
        patch.object(google_auto,'launch_context',lambda *a,**k:C()),\
        patch.object(google_auto,'search_one',side_effect=fake):
    results=google_auto.google_screen([('N4G','Tillsonburg')],{'N4G':[43,-80]},Path(tmp),max_queries=2)
   self.assertEqual(len(calls),1)
   self.assertEqual(results['N4G']['status'],'completed')
 def test_underserved_area_gets_second_query(self):
  import tempfile,google_auto
  from pathlib import Path
  from unittest.mock import patch
  class C:
   def close(self):pass
  class P:
   def __enter__(self):return self
   def __exit__(self,*a):pass
  calls=[]
  def fake(ctx,code,city,center,folder,query):
   calls.append(query)
   return {'observed_5km':2,'missing_coordinates':0,'capped':False,
       'places':[{'name':'ABC','coordinates':(43,-80),'url':'https://example.test'}],
       'source_url':'https://example.test'}
  with tempfile.TemporaryDirectory() as tmp:
   with patch.object(google_auto,'sync_playwright',lambda:P()),\
        patch.object(google_auto,'launch_context',lambda *a,**k:C()),\
        patch.object(google_auto,'search_one',side_effect=fake):
    results=google_auto.google_screen([('N4G','Tillsonburg')],{'N4G':[43,-80]},Path(tmp),max_queries=2)
   self.assertEqual(len(calls),2)
   self.assertEqual(results['N4G']['status'],'completed')
