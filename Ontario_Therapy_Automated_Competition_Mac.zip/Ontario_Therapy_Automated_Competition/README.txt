ONTARIO THERAPY COVERAGE — AUTOMATED GOOGLE MAPS + PSYCHOLOGY TODAY

A Google Maps screening of 23 initial Ontario postal areas was already run
on a real hosted Mac on November 21, 2026. The program includes that source
record and the same-day Psychology Today displayed counts. No manual Google
Maps research or entry is needed.

Initial strongest candidates:
- P5N / Kapuskasing: 2 observed geolocated Maps businesses near the FSA
  representative point; Psychology Today displays < 10 counsellors.
- N4W / Listowel: 2 observed geolocated Maps businesses, with six other links
  requiring location resolution; Psychology Today displays 10+ counsellors.

The included pilot_2026-11-21.json contains the raw place names, coordinates,
Google search URLs, completeness flags, displayed PT totals, and source run IDs
for the full 23-area sample. An incomplete source is not evidence of zero
providers. These numbers are observed business listings, not exact numbers
of therapists or a comprehensive Ontario inventory.

To run the program on your Mac:
1. Extract the ZIP to an ordinary writable folder.
2. Double-click START.command. It sets up free Python/Firefox if necessary,
   runs local tests, then opens the dashboard.
3. The dashboard immediately displays the existing observed counts.
4. Click "Automatically refresh leading areas" to have the code re-search
   up to ten promising postal areas on Google Maps. A second term is searched
   only if the first results are low enough to warrant more scrutiny.
   The code also tries to resolve a small number of unknown business locations.
5. After Google screening, the app automatically checks Psychology Today's
   latest visible first-page displayed count for the leading areas.
   The program handles counts such as "10+" and "< 10" as bounds.
6. Download the comparison CSV from the dashboard. Checkpoints and source
   evidence are saved under research_data/ so a stopped scan can resume.

No manual Maps counting is requested. Provider blocks or incomplete directories
remain flagged as unavailable, not zero competition. Public search results
may omit clinics and area-wide competition varies within large postal areas.

Current verification: live Google one-query searches for all 23 sampled FSAs
succeeded on a hosted Mac; live PT page totals were obtained for 22 of the 23
in one pass, then P5N's under-ten display was separately confirmed. The local
application passes its bundled tests. The refreshed multi-query workflow has
not completed on your own laptop.
