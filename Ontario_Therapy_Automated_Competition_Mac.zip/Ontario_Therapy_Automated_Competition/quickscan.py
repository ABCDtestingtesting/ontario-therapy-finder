#!/usr/bin/env python3
"""Ontario therapy coverage shortlisting: automated Maps then current PT.

Bounded Google Maps business-listing collection for candidate FSAs with saved
evidence and timestamped current Psychology Today counts. No paid API.
"""
from __future__ import annotations
import csv
import io
import json
import os
import re
import threading
import time
import webbrowser
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse, unquote
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
STATE = ROOT / 'research_data' / 'results.json'
CENTERS_FILE = ROOT / 'centers.json'
PILOT_FILE = ROOT / 'pilot_2026-11-21.json'
LOCAL = threading.RLock()
SLEEP_BETWEEN_REQUESTS_SECONDS = 5
CODES = re.compile(r'^[KLMNP][0-9][A-Z]$')
HAMILTON = {'L0R','L8B','L8E','L8G','L8H','L8J','L8K','L8L','L8M','L8N','L8P','L8R',
            'L8S','L8T','L8V','L8W','L9A','L9B','L9C','L9G','L9H','L9K'}
# Geographic candidates for Google checking. These are NOT verified low-Google
# competition or a province-wide minimum. Each requires the user to inspect
# its actual Google Maps results before treating it as shortlisted.
STARTERS = [
 ('N4G','Tillsonburg'), ('P1P','Gravenhurst'), ('P2A','Parry Sound'),
 ('K8A','Pembroke'), ('P1H','Huntsville'), ('N4W','Listowel'),
 ('N4K','Owen Sound'), ('L4R','Midland'), ('N8H','Leamington'),
 ('P1L','Bracebridge'), ('L9Y','Collingwood'), ('K6J','Cornwall'),
 ('K6V','Brockville'), ('K8V','Trenton'), ('N3Y','Simcoe'),
 ('N4N','Hanover'), ('P8N','Dryden'), ('P9N','Kenora'),
 ('P4N','Timmins'), ('P5N','Kapuskasing'),
 ('L6Z','Brampton'), ('L7A','Brampton'), ('N1T','Cambridge'),
]


class TextFromHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.ignore = 0
        self.anchors = []
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style','noscript'):
            self.ignore += 1
        if tag == 'a':
            d = dict(attrs)
            if d.get('href'): self.anchors.append(d['href'])
    def handle_endtag(self, tag):
        if tag in ('script','style','noscript'):
            self.ignore = max(0,self.ignore-1)
    def handle_data(self, data):
        if self.ignore == 0: self.parts.append(data)


class PTAccessError(RuntimeError):
    def __init__(self, message, blocked=False):
        super().__init__(message)
        self.blocked = blocked


def now_toronto():
    return datetime.now(ZoneInfo('America/Toronto')).isoformat(timespec='seconds')


def pt_url(code):
    return f'https://www.psychologytoday.com/ca/therapists/{code.lower()}'


def maps_url(code, city):
    from urllib.parse import quote
    return 'https://www.google.com/maps/search/?api=1&query=' + quote(f'psychotherapist counselling {city} {code} Ontario',safe='')


def parse_pt(html, code):
    """Read only a visible directory summary. Never invent an exact count."""
    parser = TextFromHTML()
    parser.feed(html)
    t = re.sub(r'\s+', ' ', ' '.join(parser.parts)).strip()
    code = code.upper()
    lower = t.lower()
    if any(x in lower[:4000] for x in ('verify you are human','captcha','unusual traffic',
             'are you a robot','access denied','checking your browser','just a moment',
             'automated traffic','request blocked','security check')):
        raise PTAccessError('Psychology Today displayed an access/verification page', blocked=True)
    if not re.search(r'\bTherapists\s+in\s+' + re.escape(code) + r'\b', t, re.I):
        raise PTAccessError(f'Directory heading for {code} was not present; no number accepted')
    heading=r'Number\s+of\s+Counsellors\s+in\s+'+re.escape(code)+r'\s*'
    less=re.search(heading+r'<\s*([\d,]+)',t,re.I)
    m = re.search(heading+r'([\d,]+)\s*(\+?)',t,re.I) if not less else None
    links = {urlparse(href).path for href in parser.anchors
             if re.search(r'/ca/therapists/[^?#/]+/\d{4,12}/?$',urlparse(href).path,re.I)}
    if not m and not less:
        raise PTAccessError(f'Visible Psychology Today total for {code} missing; source requires retry')
    number = int((less or m).group(1).replace(',',''))
    if number <= 0 or number > 100000:
        raise PTAccessError('Implausible PT displayed total; review source')
    if not links:
        raise PTAccessError('Directory total shown, but no corresponding therapist profiles were detected')
    if less:
        return {'display':f'< {number}','lower_bound':None,
                'upper_bound_exclusive':number,'rounded_lower_bound':False,
                'visible_profile_links':len(links),'method':'displayed_upper_bound'}
    is_lower_bound = bool(m.group(2))
    return {'display':f'{number}{"+" if is_lower_bound else ""}',
            'lower_bound':number,'upper_bound_exclusive':None,
            'rounded_lower_bound':is_lower_bound,
            'visible_profile_links':len(links),'method':'displayed_directory_total'}


def get_pt_summary(code, timeout=25):
    url = pt_url(code)
    req=Request(url,headers={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 13.0; rv:129.0) Gecko/20100101 Firefox/129.0',
                             'Accept':'text/html,application/xhtml+xml',
                             'Accept-Language':'en-CA,en;q=0.8'})
    try:
        with urlopen(req,timeout=timeout) as r:
            status = r.status
            final = r.url
            page = r.read(2_500_001)
    except HTTPError as e:
        raise PTAccessError(f'Psychology Today HTTP {e.code}. Use the direct link and enter the displayed count.',blocked=e.code in (401,403,429)) from e
    except (URLError,TimeoutError,OSError) as e:
        raise PTAccessError(f'Network error: {e}. Results saved; use a direct link if necessary') from e
    if status != 200 or len(page) > 2_500_000:
        raise PTAccessError(f'Unexpected HTTP response or oversized page: {status}')
    finalpath = urlparse(final).path.lower().rstrip('/')
    if finalpath != urlparse(url).path.lower().rstrip('/'):
        raise PTAccessError(f'Page redirected to {finalpath}; directory FSA could not be verified')
    return parse_pt(page.decode('utf-8','replace'),code)



def get_pt_summary_with_browser_fallback(code):
    """Try public HTML first; fall back to one ordinary Firefox page.

    This is automatic and requires no operator to count listings. An access
    challenge remains an incomplete observation.
    """
    try:
        return get_pt_summary(code)
    except PTAccessError as initial:
        if initial.blocked:raise
        from playwright.sync_api import sync_playwright
        profile=ROOT/'research_data'/'pt_browser_profile'
        profile.parent.mkdir(parents=True,exist_ok=True)
        try:
            with sync_playwright() as pw:
                ctx=pw.firefox.launch_persistent_context(str(profile),headless=False,
                                      viewport={'width':1400,'height':900},locale='en-CA')
                try:
                    page=ctx.pages[0] if ctx.pages else ctx.new_page()
                    response=page.goto(pt_url(code),wait_until='domcontentloaded',timeout=45000)
                    status=getattr(response,'status',None)
                    if status in (403,429):
                        raise PTAccessError(f'PT HTTP {status} in browser',blocked=True)
                    page.wait_for_timeout(1400)
                    page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
                    page.wait_for_timeout(700)
                    return parse_pt(page.content(),code)
                finally:ctx.close()
        except PTAccessError:raise
        except Exception as browser_exc:
            raise PTAccessError(f'PT direct request and browser both failed: '
                                f'{initial}; {browser_exc}') from browser_exc


def load():
    if STATE.exists():
        try:
            val = json.loads(STATE.read_text(encoding='utf8'))
            if isinstance(val,dict) and isinstance(val.get('areas'),dict):
                for area in val['areas'].values():
                    area.setdefault('google_status','pending' if area.get('google_count') is None else 'unverified_legacy_manual')
                    area.setdefault('google_coverage',None)
                    area.setdefault('google_error',None)
                    area.setdefault('google_sources',[])
                return val
        except (OSError,ValueError):pass
    initial={'areas':{code:{'code':code,'city':city,'google_count':None,
                            'google_checked_at':None,'google_status':'pending','google_coverage':None,'google_error':None,'google_sources':[], 'pt_count':None,'pt_checked_at':None,
                            'pt_method':None,'pt_error':None,'notes':''}
                       for code,city in STARTERS},
            'job':{'status':'idle','message':'Loaded baseline observations; click Run to refresh finalists.'},'version':2}
    if PILOT_FILE.exists():
        try:
            pilot=json.loads(PILOT_FILE.read_text(encoding='utf8'))
            for row in pilot.get('rows',[]):
                area=initial['areas'].get(row.get('fsa'))
                if area is None:continue
                area['google_count']=row.get('observed_5km')
                area['google_status']='pilot_observed'
                area['google_coverage']='one_query_'+str(row.get('coverage'))
                area['google_error']=(f"{row.get('missing_coordinates')} links without coordinates" if row.get('missing_coordinates') else None)
                area['google_sources']=[row.get('search_url')]
                area['google_checked_at']='2026-11-21T12:00:00-05:00'
                pt=row.get('pt') or {}
                if pt.get('status')=='observed':
                    area['pt_count']={'display':pt.get('display'),'lower_bound':pt.get('lower_bound'),
                         'upper_bound_exclusive':pt.get('upper_bound_exclusive'),
                         'rounded_lower_bound':pt.get('rounded',False)}
                    area['pt_checked_at']='2026-11-21T12:08:00-05:00' if row.get('fsa')=='P5N' else '2026-11-21T12:05:00-05:00'
                    area['pt_method']='live_hosted_2026_11_21'
        except (OSError,ValueError,TypeError,KeyError):pass
    return initial


def save_locked():
    STATE.parent.mkdir(parents=True,exist_ok=True)
    tmp=STATE.with_suffix('.json.tmp')
    with tmp.open('w',encoding='utf8') as file:
        json.dump(DB,file,indent=2,ensure_ascii=False)
        file.flush();os.fsync(file.fileno())
    os.replace(tmp,STATE)


def normalize_count(value, allow_blank=True):
    if value is None or (allow_blank and str(value).strip()==''):return None
    m = re.fullmatch(r'\s*(\d{1,5})\s*(\+?)\s*',str(value))
    if not m:raise ValueError('Use a nonnegative number, optionally with + (e.g. 20+)')
    v=int(m.group(1))
    return {'display':str(v)+m.group(2),'lower_bound':v,'rounded_lower_bound':bool(m.group(2))}


def candidate_view():
    rows=[]
    for v in DB['areas'].values():
        v=dict(v)
        v['google_url']=maps_url(v['code'],v['city'])
        v['pt_url']=pt_url(v['code'])
        rows.append(v)
    def order(v):
        p=v.get('pt_count') or {}
        # Google screens the candidate set; current Psychology Today counts
        # determine the priority among the screened finalists.
        verified=(v.get('google_status')=='completed' and
                  v.get('google_coverage')=='observed_complete_feeds')
        coverage=v.get('google_coverage') or ''
        quality=(0 if coverage in ('observed_complete_feeds','one_query_completed_google_result_feed')
                 else 1 if 'unresolved' in coverage and (v.get('google_error') or '').startswith(('1 ','2 ','3 ','4 ','5 ','6 ','7 ','8 ','9 '))
                 else 2 if 'unresolved' in coverage else 3 if 'capped' in coverage else 4)
        return (not verified,
                (p['upper_bound_exclusive']-1 if p.get('upper_bound_exclusive') is not None
                 else p.get('lower_bound') if p.get('lower_bound') is not None else 10**7),
                quality,
                v['google_count'] if v['google_count'] is not None else 10**7,
                v['code'])
    return sorted(rows,key=order)


def scan(codes):
    global CURRENT
    try:
        for i,code in enumerate(codes):
            if HALT.is_set():
                with LOCAL:
                    DB['job']={'status':'stopped','message':'Stopped. Completed observations remain saved.'}
                    save_locked()
                return
            with LOCAL:
                DB['job']={'status':'running','message':f'{i+1}/{len(codes)}: Psychology Today {code}'}
                save_locked()
            try:
                val=get_pt_summary_with_browser_fallback(code)
                with LOCAL:
                    DB['areas'][code]['pt_count']=val
                    DB['areas'][code]['pt_checked_at']=now_toronto()
                    DB['areas'][code]['pt_method']='live_first_page'
                    DB['areas'][code]['pt_error']=None
                    save_locked()
            except PTAccessError as exc:
                with LOCAL:
                    DB['areas'][code]['pt_error']=str(exc)
                    DB['job']={'status':'blocked' if exc.blocked else 'paused',
                               'message':f'{code}: {exc}. Earlier results saved. Review in a normal browser.'}
                    save_locked()
                return
            if i < len(codes)-1:
                if HALT.wait(SLEEP_BETWEEN_REQUESTS_SECONDS):
                    with LOCAL:
                        DB['job']={'status':'stopped','message':'Stopped. Completed observations remain saved.'}
                        save_locked()
                    return
        with LOCAL:
            DB['job']={'status':'complete','message':f'Checked {len(codes)} FSA pages. Review + counts and Google observations.'}
            save_locked()
    finally:
        with LOCAL:CURRENT=None



def automated_google_scan(codes):
    """Collect current Google results and chain directly into the PT shortlist."""
    global CURRENT
    try:
        from google_auto import google_screen
        try:centers=json.loads(CENTERS_FILE.read_text(encoding='utf8'))
        except (ValueError,OSError) as exc:
            raise RuntimeError('Verified Ontario postal area coordinates are missing: '+str(exc)) from exc
        selected=[(code,DB['areas'][code]['city']) for code in codes]
        def checkpoint(code,row):
            with LOCAL:
                area=DB['areas'][code]
                area['google_status']=row['status']
                area['google_error']=row.get('error')
                if row['status']=='completed':
                    area['google_count']=row['google_count']
                    area['google_coverage']=row['coverage']
                    area['google_sources']=row['sources']
                    area['google_checked_at']=row.get('checked_at') or now_toronto()
                DB['job']={'status':'running','message':f'Maps checked {code}: '+
                           (str(row.get('google_count'))+' visible 5-km businesses' if row['status']=='completed'
                            else row.get('error','unknown'))}
                save_locked()
        with LOCAL:
            DB['job']={'status':'running','message':f'Google Maps: starting {len(selected)} postal areas'}
            save_locked()
        result=google_screen(selected,centers,ROOT/'research_data'/'google_evidence',
                            callback=checkpoint,stop=HALT.is_set,max_queries=2)
        if HALT.is_set():
            with LOCAL:
                DB['job']={'status':'stopped','message':'Stopped. Maps evidence remains saved.'}
                save_locked()
            return
        chosen=[c for c in codes if DB['areas'][c].get('google_status')=='completed'
                and DB['areas'][c].get('google_coverage')=='observed_complete_feeds']
        chosen.sort(key=lambda c:(DB['areas'][c]['google_count'],c))
        # PT is the decisive second stage, so examine a broad group rather
        # than pretending that single Maps searches establish coverage.
        shortlist=chosen[:min(12,len(chosen))]
        with LOCAL:
            DB['job']={'status':'running','message':f'Google screen finished: {len(chosen)} complete FSAs; checking PT for {len(shortlist)} lowest observed Maps counts.'}
            save_locked()
        if shortlist:scan(shortlist)
        else:
            with LOCAL:
                DB['job']={'status':'incomplete','message':'No postal areas had verified Google result coverage; inspect saved errors.'}
                save_locked()
    except Exception as exc:
        with LOCAL:
            DB['job']={'status':'error','message':f'Google collector error: {exc}. Completed work is preserved.'}
            save_locked()
    finally:
        with LOCAL:CURRENT=None

HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Ontario therapy competition screen</title><style>
body{font:15px system-ui,-apple-system,sans-serif;margin:20px auto;max-width:1000px;padding:0 16px;color:#243247;background:#f4f7fb}h1{font-size:24px}p{line-height:1.5}.box{background:white;border:1px solid #d7dee7;border-radius:8px;padding:16px;margin:14px 0}button{background:#17577e;color:white;border:0;border-radius:5px;padding:11px;margin:3px;cursor:pointer}button:disabled{opacity:.5}.status{white-space:pre-wrap;background:#e7f0fa;padding:12px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:9px;border-bottom:1px solid #e0e7f0;text-align:left}th{background:#eff4fa}a{color:#12639d}.scroll{overflow-x:auto}small{color:#536273}.error{color:#9d2f20}
</style></head><body><h1>Ontario therapy competition screen</h1><p>The program searches Google Maps automatically for counselling providers around each Ontario postal area, deduplicates visible businesses within five kilometres, and checks current Psychology Today counts for the lowest-competition candidates. You do not need to perform the Google assessment.</p>
<div class="box"><div class="status" id="status">Loading...</div><button id="start" onclick="start()">Automatically refresh leading areas</button><button onclick="stop()">Stop</button><button onclick="location.href='/export.csv'">Export results CSV</button><p><small>Initial observations: 23 Ontario areas, collected by the code on November 21, 2026. The automatic refresh targets promising areas; Google observations are business listings, not exact numbers of therapists. Results marked capped, blocked, or incomplete are excluded from automatic conclusions. Completed work saves after every FSA.</small></p></div>
<div class="box scroll"><table><thead><tr><th>Postal area</th><th>City</th><th>Google locations (5 km)</th><th>Maps coverage</th><th>Psychology Today</th><th>Sources</th></tr></thead><tbody id="rows"></tbody></table></div>
<script>const $=id=>document.getElementById(id);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let rows=[];
async function req(u,obj){let r=await fetch(u,obj?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)}:{});let j=await r.json();if(!r.ok||j.error)throw Error(j.error||r.status);return j}
async function refresh(){try{let d=await req('/api/state');rows=d.rows;$('status').textContent=d.job.message||d.job.status;$('start').disabled=d.job.status==='running';$('rows').innerHTML=rows.map(x=>`<tr><td>${esc(x.code)}</td><td>${esc(x.city)}</td><td>${x.google_count!==null?((x.google_status==='pilot_observed'?(x.google_count===0?'Unverified (0 located)':'≥'):'')+(x.google_count===0&&x.google_status==='pilot_observed'?'':x.google_count)):'—'}</td><td>${esc(x.google_coverage||x.google_error||x.google_status)}</td><td>${esc(x.pt_count?.display||x.pt_error||'Pending')}</td><td><a target="_blank" rel="noopener" href="${esc(x.google_url)}">Maps</a> · <a target="_blank" rel="noopener" href="${esc(x.pt_url)}">PT</a></td></tr>`).join('')}catch(e){$('status').textContent=e.message}}
async function start(){try{await req('/api/auto-google',{});await refresh()}catch(e){alert(e.message)}}async function stop(){try{await req('/api/stop',{});await refresh()}catch(e){alert(e.message)}}refresh();setInterval(refresh,3000);
</script></body></html>''' 


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):pass
    def json_response(self,payload,code=200):
        b=json.dumps(payload,ensure_ascii=False).encode('utf8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store')
        self.end_headers();self.wfile.write(b)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/':
            b=HTML.encode('utf8');self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(b)))
            self.send_header('Cache-Control','no-store')
            self.end_headers();self.wfile.write(b);return
        if path=='/api/state':
            with LOCAL:self.json_response({'rows':candidate_view(),'job':DB['job']});return
        if path=='/export.csv':
            with LOCAL:rows=candidate_view()
            buf=io.StringIO();w=csv.writer(buf)
            w.writerow(['FSA','Town','Google observed businesses','Google checked at Toronto time','Google coverage','Google error',
                        'Psychology Today displayed total','PT lower bound','PT upper exclusive','Rounded +','PT checked at Toronto time',
                        'PT method','PT issue','Google Maps link','Psychology Today link'])
            for r in rows:
                pt=r.get('pt_count') or {}
                w.writerow([r['code'],r['city'],r['google_count'],r['google_checked_at'],r.get('google_coverage'),r.get('google_error'),
                        pt.get('display'),pt.get('lower_bound'),pt.get('upper_bound_exclusive'),pt.get('rounded_lower_bound'),
                        r['pt_checked_at'],r['pt_method'],r['pt_error'],r['google_url'],r['pt_url']])
            b=buf.getvalue().encode('utf-8-sig');self.send_response(200)
            self.send_header('Content-Type','text/csv; charset=utf-8')
            self.send_header('Content-Disposition','attachment; filename="Ontario_PT_competition.csv"')
            self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
        self.json_response({'error':'Unknown endpoint'},404)
    def do_POST(self):
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=10000:raise ValueError('Invalid request length')
            j=json.loads(self.rfile.read(n))
            path=urlparse(self.path).path
            if path=='/api/auto-google':
                global CURRENT
                candidates=[]
                for c,a in DB['areas'].items():
                    if c in HAMILTON:continue
                    p=a.get('pt_count') or {}
                    upper=p.get('upper_bound_exclusive')
                    lower=p.get('lower_bound')
                    pt_score=(upper-1 if upper is not None else lower if lower is not None else 10**6)
                    if a.get('google_count') is not None and a['google_count']<=15 and pt_score<=40:
                        candidates.append((pt_score,a['google_count'],c))
                candidates.sort()
                codes=[c for _,_,c in candidates[:10]] or [c for c in DB['areas'] if c not in HAMILTON]
                with LOCAL:
                    if CURRENT is not None and CURRENT.is_alive():raise ValueError('Scan already active')
                    HALT.clear()
                    CURRENT=threading.Thread(target=automated_google_scan,args=(codes,),daemon=True)
                    CURRENT.start()
            elif path=='/api/scan':
                codes=list(dict.fromkeys(str(x).upper() for x in j.get('codes',[])))
                if not codes or len(codes)>100 or any(x not in DB['areas'] for x in codes):
                    raise ValueError('Select 1–100 listed Ontario postal areas')
                with LOCAL:
                    if CURRENT is not None and CURRENT.is_alive():raise ValueError('Scan already active')
                    HALT.clear()
                    DB['job']={'status':'running','message':f'Starting {len(codes)} first-page checks'}
                    save_locked()
                    CURRENT=threading.Thread(target=scan,args=(codes,),daemon=True)
                    CURRENT.start()
            elif path=='/api/stop':
                HALT.set()
            else:
                return self.json_response({'error':'Unknown endpoint'},404)
            return self.json_response({'ok':True})
        except (ValueError,TypeError,KeyError,JSONDecodeError) as e:
            return self.json_response({'error':str(e)},400)
        except Exception as e:
            return self.json_response({'error':'Application error: '+str(e)},500)


from json import JSONDecodeError
DB=load()
HALT=threading.Event()
CURRENT=None


def run():
    app=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    addr=f'http://127.0.0.1:{app.server_port}/'
    print('\nOntario Therapy Quick Scan is running at '+addr+'\n',flush=True)
    print('Keep this window open. Your results save in research_data/results.json. Press Ctrl+C to stop.',flush=True)
    webbrowser.open(addr)
    try:app.serve_forever()
    except KeyboardInterrupt:pass
    finally:app.server_close()

if __name__=='__main__':run()
