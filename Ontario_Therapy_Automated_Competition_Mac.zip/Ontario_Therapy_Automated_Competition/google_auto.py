"""Automated, bounded Google Maps location screen for Ontario FSAs.

One map-result feed per FSA, plus a second query only for promising areas.
Reports observed, geolocated *business listings*, not a count of clinicians.
Incomplete, capped, or blocked feeds never become verified zero results.
"""
from __future__ import annotations
import json, math, re, time
from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.parse import quote, unquote
from pathlib import Path
from playwright.sync_api import sync_playwright

END=("you've reached the end of the list", "you’ve reached the end of the list", "end of the list", "you have reached the end of the list")
EMPTY=("no results found", "no results for", "google maps can't find", "google maps can’t find")
BLOCK=("unusual traffic", "are you a robot", "verify you are human", "recaptcha", "too many requests", "access denied", "request blocked", "captcha")
MAX_VISIBLE=120

class MapsIncomplete(RuntimeError):pass
class MapsBlocked(MapsIncomplete):pass

def haversine(a,b):
    lat1,lon1=a;lat2,lon2=b
    q=math.pi/180
    x=math.sin((lat2-lat1)*q/2)**2+math.cos(lat1*q)*math.cos(lat2*q)*math.sin((lon2-lon1)*q/2)**2
    return 12742*math.asin(min(1,math.sqrt(x)))

def place_coordinates(url):
    url=unquote(url)
    m=list(re.finditer(r'!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)',url))
    if m:
        lat,lon=map(float,m[-1].groups())
        return (lat,lon) if 41<lat<57 and -96<lon<-73 else None
    m=list(re.finditer(r'!2d(-?\d+(?:\.\d+)?)!3d(-?\d+(?:\.\d+)?)',url))
    if m:
        lon,lat=map(float,m[-1].groups())
        return (lat,lon) if 41<lat<57 and -96<lon<-73 else None
    return None

def listing_key(x):
    lat,lon=x['coordinates']; name=x['name'].strip().casefold()
    name=re.sub(r'[^a-z0-9]+','',name)
    return f'{name}|{lat:.4f}|{lon:.4f}'

def normalize_links(links,center,radius_km=5):
    selected={};without_coordinates=0;remote=0
    for a in links:
        url=a.get('url') or a.get('href') or ''
        name=(a.get('name') or a.get('text') or unquote(url.split('/maps/place/')[-1].split('/')[0]).replace('+',' ')).strip()
        coords=a.get('coordinates') or place_coordinates(url)
        if not coords:without_coordinates+=1;continue
        if haversine(coords,center)>radius_km:remote+=1;continue
        if not name:continue
        item={'name':name,'url':url,'coordinates':coords}
        selected[listing_key(item)]=item
    return {'places':list(selected.values()),'missing_coordinates':without_coordinates,'outside_radius':remote}

def parse_browser_result(code,center,feed,radius_km=5):
    """Make an independently auditable and conservative per-FSA observation."""
    if feed.get('blocked'):raise MapsBlocked(feed.get('error') or 'Google access restricted')
    if not feed.get('completed'):raise MapsIncomplete('No verified Google Maps end-of-results marker')
    links=feed.get('place_links',[])
    locations=normalize_links(links,center,radius_km)
    capped=len(links)>=MAX_VISIBLE
    # A capped result may omit other practices, but the observed geolocated
    # locations are still useful as a lower bound, never an exhaustive total.
    state='capped_lower_bound' if capped else 'observed_complete_feed'
    if locations['missing_coordinates']:
        state='unresolved_location_links'
    return {'fsa':code,'observed_5km':len(locations['places']),
            'query_visible_count':len(links),'coverage':state,
            'capped':capped,'missing_coordinates':locations['missing_coordinates'],
            'outside_radius':locations['outside_radius'],'places':locations['places'],
            'source_url':feed.get('search_url'),'completion_reason':feed.get('completion_reason')}

def _evidence(page):
    return page.eval_on_selector_all('a[href*="/maps/place/"]',
         '''xs=>xs.map(a=>({url:a.href,name:(a.getAttribute('aria-label')||a.innerText||'').trim()}))''')


def recover_place_coordinates(context,link,timeout_ms=11000):
    """Resolve a missing Maps business coordinate from its own detail URL.

    Never substitute map viewport coordinates for business coordinates.
    """
    tab=context.new_page()
    try:
        response=tab.goto(link,wait_until='domcontentloaded',timeout=timeout_ms)
        if getattr(response,'status',None) in (403,429):raise MapsBlocked('Google Maps restricted detail page lookups')
        for _ in range(3):
            urls=[tab.url]
            for selector,attribute in (('link[rel="canonical"]','href'),('meta[property="og:url"]','content')):
                nodes=tab.locator(selector)
                if nodes.count():
                    u=nodes.first.get_attribute(attribute)
                    if u:urls.append(u)
            for url in urls:
                point=place_coordinates(url)
                if point:return point
            tab.wait_for_timeout(450)
        return None
    finally:tab.close()

def search_one(context,code,city,center,folder,query='psychotherapist',timeout_seconds=75):
    """One real browser search; no grid or rotating sessions to bypass blocks."""
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    lat,lon=center
    url=f'https://www.google.com/maps/search/{quote(query,safe="")}/@{lat:.6f},{lon:.6f},14z?hl=en'
    page=context.new_page();links={};finished=False;reason=None
    try:
        response=page.goto(url,wait_until='domcontentloaded',timeout=35000)
        status=getattr(response,'status',None)
        if status in (403,429):raise MapsBlocked(f'Google Maps HTTP {status}')
        if status and status>=500:raise MapsIncomplete(f'Google Maps HTTP {status}')
        deadline=time.monotonic()+timeout_seconds;stagnant=0;previous=None
        while time.monotonic()<deadline:
            body=page.locator('body').inner_text(timeout=9000).lower()
            if any(x in body for x in BLOCK):raise MapsBlocked('Google Maps human verification or rate limit')
            for a in _evidence(page):
                if '/maps/place/' in a['url']:links[a['url']]=a['name']
            if any(x in body for x in END):finished=True;reason='visible_end_of_list';break
            if not links and any(x in body for x in EMPTY):finished=True;reason='explicit_no_results';break
            feed=page.locator('[role="feed"]')
            if not feed.count():
                page.wait_for_timeout(700);continue
            box=feed.first.evaluate('e=>({height:e.scrollHeight,top:e.scrollTop,client:e.clientHeight})')
            current=(len(links),box['height'],box['top'])
            stagnant=(stagnant+1) if current==previous else 0
            if stagnant>25:break
            previous=current
            feed.first.evaluate('e=>e.scrollBy(0,Math.max(500,e.clientHeight*0.85))')
            page.wait_for_timeout(600)
        evidence=[{'url':href,'name':name,'coordinates':place_coordinates(href)}
                  for href,name in links.items()]
        # Only a small number of unresolved links merits additional requests.
        # Recovery is automated; an ambiguous detail page remains unresolved.
        missing=[x for x in evidence if not x['coordinates']]
        recovered=0
        if finished and 0<len(missing)<=8:
            for item in missing:
                try:
                    coords=recover_place_coordinates(context,item['url'])
                    if coords:item['coordinates']=coords;recovered+=1
                except MapsBlocked:raise
                except Exception:pass
        result={'fsa':code,'city':city,'query':query,'search_url':url,'completed':finished,
                'completion_reason':reason,'place_links':evidence,
                'recovered_coordinates':recovered}
        (folder/'search.json').write_text(json.dumps(result,indent=2),encoding='utf8')
        if not finished:raise MapsIncomplete('No confirmed end of list; search evidence saved')
        return parse_browser_result(code,center,result)
    except Exception as exc:
        try:page.screenshot(path=str(folder/'failure.png'))
        except Exception:pass
        (folder/'failure.json').write_text(json.dumps({'fsa':code,'url':url,'error':str(exc),'visible_place_links':len(links)},indent=2),encoding='utf8')
        raise
    finally:page.close()

def launch_context(pw,data_path,headless=False):
    return pw.firefox.launch_persistent_context(str(data_path),headless=headless,
           viewport={'width':1400,'height':960},locale='en-CA')


def google_screen(areas,centers,root,callback=lambda *x:None,stop=lambda:False,
                  headless=False,context_factory=None,max_queries=2):
    """Scan areas sequentially and checkpoint each. Optional second term for low counts.

    Areas without trusted centroids are skipped; never guess coordinates.
    """
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    results={};blocked=False
    with sync_playwright() as pw:
        context=context_factory(pw) if context_factory else launch_context(pw,root/'firefox_profile',headless=headless)
        try:
            for code,city in areas:
                if stop():break
                out=root/code;out.mkdir(exist_ok=True)
                resultfile=out/'summary.json'
                if resultfile.exists():
                    try:
                        cached=json.loads(resultfile.read_text())
                        if cached.get('status')=='completed':results[code]=cached;callback(code,cached);continue
                    except (ValueError,OSError):pass
                if code not in centers:
                    val={'status':'unavailable','error':'Missing verified FSA centroid','fsa':code}
                    results[code]=val;callback(code,val);continue
                center=centers[code]
                pieces=[]
                problem=None
                for term in ('psychotherapist','counselling')[:max_queries]:
                    # Verify low-observed competition with a second term.
                    # A crowded or capped first search needs no further calls.
                    if pieces and (pieces[0]['capped'] or
                                   pieces[0]['missing_coordinates'] or
                                   pieces[0]['observed_5km']>15):
                        break
                    q=f'{term} {city} {code} Ontario'
                    try:
                        val=search_one(context,code,city,center,out/term,query=q)
                        pieces.append(val)
                    except MapsBlocked as exc:
                        blocked=True;problem={'status':'blocked','fsa':code,'error':str(exc)}
                        break
                    except Exception as exc:
                        problem={'status':'incomplete','fsa':code,'error':str(exc)}
                        break
                if problem is not None:val=problem
                else:
                    listings={}
                    for part in pieces:
                        for item in part['places']:listings[listing_key(item)]=item
                    val={'status':'completed','fsa':code,
                        'checked_at':datetime.now(ZoneInfo('America/Toronto')).isoformat(timespec='seconds'),
                        'google_count':len(listings),
                        'coverage':'capped_lower_bound' if any(x['capped'] for x in pieces) else 'observed_complete_feeds',
                        'queries':len(pieces),'sources':[x['source_url'] for x in pieces],
                        'missing_coordinates':sum(x['missing_coordinates'] for x in pieces),
                        'places':list(listings.values()),'radius_km':5}
                    if val['missing_coordinates']:val['coverage']='unresolved_location_links'
                if val['status']=='completed':resultfile.write_text(json.dumps(val,indent=2),encoding='utf8')
                results[code]=val;callback(code,val)
                if blocked or stop():break
        finally:context.close()
    return results
