import tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import quickscan
import google_auto

class AutomationIntegrationTests(unittest.TestCase):
    def test_maps_shortlist_starts_pt_without_manual_counts(self):
        old_db,old_state,old_centers=quickscan.DB,quickscan.STATE,quickscan.CENTERS_FILE
        with tempfile.TemporaryDirectory() as tmp:
            try:
                root=Path(tmp)
                quickscan.STATE=root/'research_data'/'results.json'
                quickscan.CENTERS_FILE=root/'centers.json'
                quickscan.CENTERS_FILE.write_text('{"N4G":[42.85,-80.71],"P2A":[45.36,-79.83]}')
                quickscan.DB={'areas':{
                  'N4G':{'code':'N4G','city':'Tillsonburg','google_count':None,'google_status':'pending', 'pt_count':None},
                  'P2A':{'code':'P2A','city':'Parry Sound','google_count':None,'google_status':'pending', 'pt_count':None}},'job':{'status':'idle','message':''}}
                def fake_google(areas,centers,folder,callback,stop,max_queries):
                    callback('P2A',{'status':'completed','google_count':6,'coverage':'observed_complete_feeds','sources':['maps://P2A']})
                    callback('N4G',{'status':'completed','google_count':2,'coverage':'observed_complete_feeds','sources':['maps://N4G']})
                    return {}
                shortlist=[]
                def fake_pt(codes):shortlist.extend(codes)
                quickscan.HALT.clear()
                with patch.object(google_auto,'google_screen',side_effect=fake_google),patch.object(quickscan,'scan',side_effect=fake_pt):
                    quickscan.automated_google_scan(['P2A','N4G'])
                self.assertEqual(shortlist,['N4G','P2A'])
                self.assertEqual(quickscan.DB['areas']['N4G']['google_count'],2)
                self.assertIsNotNone(quickscan.DB['areas']['N4G']['google_checked_at'])
            finally:
                quickscan.DB,quickscan.STATE,quickscan.CENTERS_FILE=old_db,old_state,old_centers
                quickscan.HALT.clear()

    def test_unresolved_google_is_not_treated_as_low_competition(self):
        old_db,old_state,old_centers=quickscan.DB,quickscan.STATE,quickscan.CENTERS_FILE
        with tempfile.TemporaryDirectory() as tmp:
            try:
                root=Path(tmp)
                quickscan.STATE=root/'research_data'/'results.json'
                quickscan.CENTERS_FILE=root/'centers.json'
                quickscan.CENTERS_FILE.write_text('{"N4G":[42.85,-80.71]}')
                quickscan.DB={'areas':{'N4G':{'code':'N4G','city':'Tillsonburg','google_count':None,'google_status':'pending','pt_count':None}},'job':{'status':'idle','message':''}}
                def fake_google(areas,centers,folder,callback,stop,max_queries):
                    callback('N4G',{'status':'blocked','error':'Google needs verification'})
                    return {}
                with patch.object(google_auto,'google_screen',side_effect=fake_google),patch.object(quickscan,'scan') as pt:
                    quickscan.automated_google_scan(['N4G'])
                    pt.assert_not_called()
                self.assertIsNone(quickscan.DB['areas']['N4G']['google_count'])
                self.assertEqual(quickscan.DB['job']['status'],'incomplete')
            finally:
                quickscan.DB,quickscan.STATE,quickscan.CENTERS_FILE=old_db,old_state,old_centers
                quickscan.HALT.clear()
if __name__=='__main__':unittest.main()

class VerifiedPilotDataTests(unittest.TestCase):
    def test_live_google_and_pt_rows_are_preloaded_without_treating_pilot_as_complete(self):
        import json
        from pathlib import Path
        ref=Path(quickscan.__file__).with_name('pilot_2026-11-21.json')
        pilot=json.loads(ref.read_text(encoding='utf8'))
        self.assertEqual(len(pilot['rows']),23)
        p5n=next(r for r in pilot['rows'] if r['fsa']=='P5N')
        self.assertEqual(p5n['observed_5km'],2)
        self.assertEqual(p5n['pt']['display'],'< 10')
        n4w=next(r for r in pilot['rows'] if r['fsa']=='N4W')
        self.assertGreater(n4w['missing_coordinates'],0)
        self.assertEqual(n4w['pt']['display'],'10+')
    def test_fsa_centres_are_all_verified_and_present(self):
        import json
        from pathlib import Path
        root=Path(quickscan.__file__).parent
        centers=json.loads((root/'centers.json').read_text())
        self.assertEqual(set(centers),{code for code,_ in quickscan.STARTERS})
        self.assertTrue(all(41<lat<57 and -96<lon<-73 for lat,lon in centers.values()))

class DashboardRouteTests(unittest.TestCase):
    def test_one_click_starts_automatic_shortlist_without_manual_entries(self):
        import json,threading
        from urllib.request import Request,urlopen
        from http.server import ThreadingHTTPServer
        calls=[]
        def fake_auto(codes):calls.extend(codes)
        saved=quickscan.CURRENT
        quickscan.CURRENT=None
        server=ThreadingHTTPServer(('127.0.0.1',0),quickscan.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with patch.object(quickscan,'automated_google_scan',side_effect=fake_auto):
                u=f'http://127.0.0.1:{server.server_port}/api/auto-google'
                req=Request(u,data=b'{}',headers={'Content-Type':'application/json'},method='POST')
                with urlopen(req,timeout=5) as resp:
                    result=json.load(resp)
                self.assertTrue(result['ok'])
                if quickscan.CURRENT:quickscan.CURRENT.join(timeout=5)
                self.assertIn('P5N',calls)
                self.assertIn('N4W',calls)
                self.assertLessEqual(len(calls),10)
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)
            quickscan.CURRENT=saved
