#!/bin/zsh
set -u
cd "${0:A:h}" || exit 1
printf '\nONTARIO THERAPY COVERAGE — TWO INDEPENDENT RUNS\n\n'
failed() { print "\nSetup failed: $1"; read -k 1 'x?Press a key to close...'; exit 1; }
PY=''
for candidate in /opt/homebrew/bin/python3.13 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.13 /usr/local/bin/python3.12 "$(command -v python3 2>/dev/null)"; do
 if [[ -n "$candidate" && -x "$candidate" ]] && "$candidate" -c 'import sys;assert sys.version_info >= (3,10)' >/dev/null 2>&1;then PY="$candidate";break;fi
done
if [[ -z "$PY" ]];then
 print 'Installing free local Python runtime...'
 mkdir -p .quickscan_tools || failed 'Cannot create runtime folder'
 curl -fLsS --retry 3 https://astral.sh/uv/install.sh -o .quickscan_tools/uv_install.sh || failed 'Cannot download Python installer'
 UV_INSTALL_DIR="$PWD/.quickscan_tools" UV_NO_MODIFY_PATH=1 /bin/sh .quickscan_tools/uv_install.sh || failed 'Python runtime manager failed'
 export UV_PYTHON_INSTALL_DIR="$PWD/.quickscan_tools/managed_python"
 .quickscan_tools/uv python install 3.12 || failed 'Cannot install managed Python'
 PY="$(.quickscan_tools/uv python find 3.12 --managed-python --python-preference only-managed)"
 [[ -x "$PY" ]] || failed 'Managed Python not executable'
fi
if [[ ! -x .venv/bin/python ]];then "$PY" -m venv .venv || failed 'Cannot create Python environment';fi
source .venv/bin/activate || failed 'Cannot activate Python environment'
if ! python -c 'import playwright' >/dev/null 2>&1;then
 print 'Installing local browser automation...'
 python -m pip install 'playwright>=1.49,<2' || failed 'Cannot install Playwright'
fi
python -m playwright install firefox || failed 'Cannot install free Firefox browser'
print 'Checking application and saved data...'
python -m unittest discover -q || failed 'Automated tests failed; application not launched'
[[ -f ontario_fsa_pool.json ]] || failed 'Missing Ontario FSA candidate pool'
print 'Opening local dashboard...'
python staged.py
code=$?
print "\nProgram ended with code $code. Results remain in research_data/."
read -k 1 'x?Press a key to close...'
