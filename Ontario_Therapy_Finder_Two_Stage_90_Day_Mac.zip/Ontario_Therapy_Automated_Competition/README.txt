Ontario Therapy Finder — separate Ontario Google and Psychology Today scans

1. Unzip the whole package to your Desktop or Documents.
2. Double-click START.command. Leave its Terminal window open.
3. Stage 1: Click "Scan next 60 postal areas". The program automatically searches Google Maps around Ontario 2021 census FSA representative points, calculates unique business-listing locations within 5 km, and saves the results after each postal area. The first click never searches Psychology Today. Repeat Stage 1 to examine more areas (up to the official list); you can export the Google shortlist at any time.
4. Stage 2: Later this week, click "Check Psychology Today now". This stage makes current directory requests only for Stage 1's low-Google-competition candidates. It saves the date and displayed total (including values like < 10 and 10+). It does not repeat province-wide Google searches.
5. After Stage 2 has completed, click "Finalize this campaign and record 90-day exclusions". Export the final comparison CSV. The codes in that finalized shortlist will be excluded from the next campaign for 90 days. The same codes are permitted between Stage 1 and Stage 2 of one campaign.

The package includes 401 official populated Ontario FSA representative points and census populations. It reports how many have actually been scanned. The included data come from 2021 Statistics Canada, limited to FSA population >=12,000 and with the established Hamilton-related FSA exclusion. The program can incrementally check every remaining eligible area. Other sizes can be included by revising the source criteria.

Previously returned recommendations excluded through the 90-day history on 21 Nov 2026: L6Z, L7A, L6X, N1T, N3S, P5N, N4W. Previously examined areas without a returned recommendation are eligible; the distinction prevents losing entire markets just because they appeared in a pilot test.

Google collection retrieves publicly visible result listings and has coverage limitations: incomplete/challenged/capped/unlocated searches are excluded from the qualified final shortlist. Business listings are not individual therapists and the observed Google count is not a guaranteed exhaustive census of every service. Two Google queries at most per chosen area (one for busier areas). Each request takes time; a 60-area batch can take an extended period and may need resuming. Verification and rate limits cannot be bypassed. An interrupted scan preserves completed areas.

The PT count reflects the site's displayed directory total at the time of the second scan, not an independently confirmed number of in-person practitioners. If Psychology Today blocks a request, the run pauses with the completed pages saved and a visible error. Final comparison refuses missing counts.

The persistent campaign history and 90-day exclusion ledger are stored outside the extracted ZIP at ~/Library/Application Support/Ontario Therapy Finder/staged_results.json. This survives app upgrades and re-extracting the ZIP. Browser evidence is saved next to that file. The old quickscan.py remains for backward compatibility.
