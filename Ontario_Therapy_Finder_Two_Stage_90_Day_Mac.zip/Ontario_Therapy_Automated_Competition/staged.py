#!/usr/bin/env python3
"""Two separate runs: broad Google Maps shortlist, then current PT comparison.

Persist every observation, campaign, and 90-day no-repeat recommendation ledger.
The second stage remains eligible to examine its own first-stage shortlist.
"""
from __future__ import annotations
import csv, io, json, os, threading, uuid, webbrowser
from datetime import datetime, timedelta, timezone
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from urllib.request import urlopen, Request
from zoneinfo import ZoneInfo
import quickscan

ROOT=Path(__file__).resolve().parent
USER_DATA=Path(os.environ.get('THERAPY_DATA_HOME') or (Path.home()/'Library'/'Application Support'/'Ontario Therapy Finder'))
STATE=USER_DATA/'staged_results.json'
POOL=ROOT/'ontario_fsa_pool.json'
OLD_CENTERS=ROOT/'centers.json'
LOCK=threading.RLock()
HALT=threading.Event()
THREAD=None
EXCLUDE_DAYS=90
BATCH_SIZE=60
MAX_MAPS_PER_CAMPAIGN=400
GOOGLE_SHORTLIST_MAX=100
# Codes previously RETURNED as possible sites; observation-only codes are not suppressed.
HISTORY=[('L6Z','2026-11-20'),('L7A','2026-11-20'),('L6X','2026-11-20'),
         ('N1T','2026-11-20'),('N3S','2026-11-20'),('P5N','2026-11-21'),('N4W','2026-11-21')]

def now():return datetime.now(ZoneInfo('America/Toronto')).isoformat(timespec='seconds')
def today():return datetime.now(ZoneInfo('America/Toronto')).date()
def date_of(s):return datetime.fromisoformat(s).date()

def load_pool(path=POOL):
    raw=json.loads(Path(path).read_text('utf-8'))
    rows=raw['areas'] if isinstance(raw,dict) else raw
    pool={}
    for row in rows:
        code=str(row['fsa']).upper()
        if not quickscan.CODES.fullmatch(code) or code in quickscan.HAMILTON:continue
        lat,lon=float(row['lat']),float(row['lon'])
        if not 41<lat<57 or not -96<lon<-73:raise ValueError('Invalid Ontario FSA coordinates for '+code)
        population=int(row.get('population_2021',0))
        if population<12000:continue
        if code in pool:raise ValueError('Duplicate postal area in source: '+code)
        pool[code]={'fsa':code,'lat':lat,'lon':lon,'population_2021':population,
                    'city':row.get('city') or code}
    if len(pool)<100:raise ValueError('The Ontario source pool is incomplete: '+str(len(pool))+' areas (need at least 100).')
    return pool

OFFICIAL_POOL_URL='https://raw.githubusercontent.com/ABCDtestingtesting/ontario-therapy-finder/ci-diagnostics/official_ontario_fsa_pool.json'

def refresh_official_pool():
    """Replace bundled 136-area fallback with 401 official populated Ontario FSAs.

    Fetch once using an ordinary public GitHub raw file. If unavailable, use
    bundled source coordinates; never falsely claim the fallback covers Ontario.
    """
    current_pool=load_pool()
    if len(current_pool)>=400:return len(current_pool)
    try:
        req=Request(OFFICIAL_POOL_URL,headers={'User-Agent':'Ontario-Therapy-Finder/3.0'})
        with urlopen(req,timeout=25) as response:
            raw=response.read(250000)
            if len(raw)>=250000:raise ValueError('Official pool unexpectedly large')
        obj=json.loads(raw)
        areas=obj['areas']
        if len(areas)<400:raise ValueError('Official source returned too few areas')
        if not all('fsa' in p and 'lat' in p and 'lon' in p and 'population_2021' in p for p in areas):
            raise ValueError('Official FSA fields missing')
        temp=POOL.with_suffix('.download')
        temp.write_text(json.dumps(obj,indent=2),encoding='utf8')
        try:validated=load_pool(temp)
        except Exception:temp.unlink(missing_ok=True);raise
        if len(validated)<390:raise ValueError('Validated pool smaller than expected')
        os.replace(temp,POOL)
        return len(validated)
    except Exception as exc:
        print('Official full Ontario pool update unavailable; bundled province subset remains:',exc,flush=True)
        return len(current_pool)

def fresh_state():
    return {'version':3,'history':[{'code':c,'date':d,'origin':'previously returned'} for c,d in HISTORY],
            'campaigns':[],'status':{'state':'idle','message':'Run Stage 1 for a large Maps shortlist; run Stage 2 separately this week.'}}

def load():
    if STATE.exists():
        data=json.loads(STATE.read_text('utf-8'))
        if not isinstance(data.get('campaigns'),list) or not isinstance(data.get('history'),list):
            raise ValueError('Saved campaign history is malformed; data left untouched')
        return data
    return fresh_state()

DB=load()

def persist():
    STATE.parent.mkdir(parents=True,exist_ok=True)
    tmp=STATE.with_suffix('.tmp')
    with tmp.open('w',encoding='utf8') as f:
        json.dump(DB,f,indent=2,ensure_ascii=False)
        f.flush();os.fsync(f.fileno())
    os.replace(tmp,STATE)

def excluded(history,on=None):
    on=on or today()
    result=set()
    for row in history:
        try:
            when=date_of(row['date'])
            if timedelta(days=0)<=on-when<timedelta(days=EXCLUDE_DAYS):result.add(row['code'])
        except (ValueError,TypeError,KeyError):continue
    return result

def start_campaign(pool,on=None):
    on=on or today()
    off=excluded(DB['history'],on)
    # Begin with smaller populated FSAs, distributed across regions by rotating
    # initial postal letter, while progressively examining every eligible FSA.
    available=[p for p in pool.values() if p['fsa'] not in off]
    buckets={letter:[] for letter in 'KL MNP'.replace(' ','')}
    for p in available:buckets[p['fsa'][0]].append(p)
    for bucket in buckets.values():bucket.sort(key=lambda p:(p['population_2021'],p['fsa']))
    ordered=[]
    while any(buckets.values()):
        for letter in buckets:
            if buckets[letter]:ordered.append(buckets[letter].pop(0)['fsa'])
    campaign={'id':str(uuid.uuid4())[:12],'created':on.isoformat(),
              'pool_total':len(pool),'excluded_previous_90_days':sorted(off),
              'queue':ordered,'maps':{},'shortlist':[], 'pt':{},
              'stage1':'pending','stage2':'not_started','published':False,
              'stage1_checked':None,'stage2_checked':None}
    return campaign

def current():
    return DB['campaigns'][-1] if DB['campaigns'] else None

def eligible_shortlist(campaign,limit=GOOGLE_SHORTLIST_MAX):
    verified=[]
    for code,row in campaign['maps'].items():
        if row.get('status')!='completed' or row.get('coverage')!='observed_complete_feeds':continue
        if row.get('missing_coordinates') or row.get('google_count') is None:continue
        if row['google_count']>25:continue
        verified.append((row['google_count'],code))
    verified.sort()
    return [c for _,c in verified[:limit]]

def stage1(batch=BATCH_SIZE):
    global THREAD
    from google_auto import google_screen
    try:
        pool=load_pool()
        with LOCK:
            camp=current()
            if camp and camp['stage2']!='not_started' and not camp.get('published'):
                raise ValueError('Stage 2 has already started for this campaign. Finish or resume it before starting a new campaign.')
            if not camp or camp.get('published'):
                camp=start_campaign(pool)
                DB['campaigns'].append(camp)
            queue=[c for c in camp['queue'] if c not in camp['maps']]
            selected=queue[:batch]
            if not selected:
                camp['stage1']='complete';camp['shortlist']=eligible_shortlist(camp)
                DB['status']={'state':'complete','message':'Stage 1 area queue finished. Run Stage 2 separately.'}
                persist();return
            camp['stage1']='running'
            DB['status']={'state':'running','message':f'Stage 1 checking {len(selected)} more Ontario areas; {len(camp["maps"])} already saved.'}
            persist()
        coords={c:[pool[c]['lat'],pool[c]['lon']] for c in selected}
        areas=[(c,pool[c]['city']) for c in selected]
        def checkpoint(code,row):
            with LOCK:
                camp['maps'][code]={k:v for k,v in row.items() if k!='places'}
                if row.get('status')=='blocked':
                    camp['stage1']='blocked'
                camp['shortlist']=eligible_shortlist(camp)
                DB['status']={'state':'running','message':f'Stage 1: {len(camp["maps"])} areas checked, {len(camp["shortlist"])} qualifying Maps candidates.'}
                persist()
        google_screen(areas,coords,STATE.parent/'google_evidence'/camp['id'],
                      callback=checkpoint,stop=HALT.is_set,max_queries=2)
        with LOCK:
            blocked=any(camp['maps'].get(c,{}).get('status')=='blocked' for c in selected)
            camp['stage1']='blocked' if blocked else ('stopped' if HALT.is_set() else 'batch_complete')
            camp['stage1_checked']=now()
            camp['shortlist']=eligible_shortlist(camp)
            remaining=len([c for c in camp['queue'] if c not in camp['maps']])
            DB['status']={'state':camp['stage1'],'message':f'Stage 1 saved {len(camp["maps"])} Maps checks; {len(camp["shortlist"])} verified low-competition candidates. {remaining} eligible areas not yet scanned. Run Stage 1 again for next batch, or Stage 2 this week.'}
            persist()
    except Exception as exc:
        with LOCK:
            DB['status']={'state':'error','message':'Stage 1 stopped: '+str(exc)}
            persist()
    finally:
        with LOCK:THREAD=None

def stage2():
    global THREAD
    try:
        with LOCK:
            camp=current()
            if not camp:raise ValueError('Run Stage 1 before checking Psychology Today')
            if camp.get('published'):raise ValueError('This campaign is already published. Start a new Stage 1 campaign.')
            shortlist=list(camp['shortlist'])
            if not shortlist:raise ValueError('Stage 1 has no qualified Google Maps shortlist yet')
            camp['stage2']='running';persist()
        for code in shortlist:
            if HALT.is_set():break
            # Repeated within same campaign is permitted, but don't treat stale
            # prior-week counts as current when re-running this week's scan.
            old=camp['pt'].get(code) or {}
            if old.get('checked_at') and date_of(old['checked_at'])==today() and old.get('status')=='checked':continue
            try:
                value=quickscan.get_pt_summary_with_browser_fallback(code)
                row={'status':'checked','count':value,'checked_at':now(),'source':quickscan.pt_url(code)}
            except quickscan.PTAccessError as exc:
                row={'status':'blocked' if exc.blocked else 'incomplete','error':str(exc),
                     'checked_at':now(),'source':quickscan.pt_url(code)}
                with LOCK:
                    camp['pt'][code]=row;camp['stage2']='blocked' if exc.blocked else 'incomplete';persist()
                break
            with LOCK:
                camp['pt'][code]=row
                DB['status']={'state':'running','message':f'Stage 2: checked current Psychology Today for {len(camp["pt"])} of {len(shortlist)} candidates.'}
                persist()
            if HALT.wait(2):break
        with LOCK:
            success=all(camp['pt'].get(c,{}).get('status')=='checked' and date_of(camp['pt'][c]['checked_at'])>=today()-timedelta(days=7) for c in shortlist)
            camp['stage2']='complete' if success else 'stopped' if HALT.is_set() else camp['stage2'] if camp['stage2'] in ('blocked','incomplete') else 'incomplete'
            camp['stage2_checked']=now()
            DB['status']={'state':camp['stage2'],'message':f'Stage 2: {sum(camp["pt"].get(c,{}).get("status")=="checked" for c in shortlist)}/{len(shortlist)} current PT results. '+('Ready to publish and add codes to the 90-day history.' if success else 'Resume incomplete sources before publishing.')}
            persist()
    except Exception as exc:
        with LOCK:
            DB['status']={'state':'error','message':'Stage 2: '+str(exc)};persist()
    finally:
        with LOCK:THREAD=None

def ranked(camp):
    rows=[]
    for c in camp['shortlist']:
        maps=camp['maps'][c];pt=camp['pt'].get(c,{})
        score=pt.get('count') or {}
        lo=score.get('lower_bound');hi=score.get('upper_bound_exclusive')
        key=hi-1 if hi is not None else lo if lo is not None else 10**9
        rows.append({'code':c,'google_count':maps['google_count'], 'google_checked_at':maps.get('checked_at'),
           'google_coverage':maps.get('coverage'),'pt_display':score.get('display'),
           'pt_checked_at':pt.get('checked_at'),'pt_status':pt.get('status','not_checked'),
           'pt_url':quickscan.pt_url(c),'google_sources':maps.get('sources',[]),'score':key})
    return sorted(rows,key=lambda x:(x['score'],x['google_count'],x['code']))

def google_report(camp):
    shortlist=set(camp.get('shortlist',[]))
    result=[]
    for code,data in camp.get('maps',{}).items():
        value=data.get('google_count')
        result.append({'code':code,'google_count':value,'google_status':data.get('status'),
          'google_coverage':data.get('coverage'),'google_error':data.get('error'),
          'checked_at':data.get('checked_at'),'source':'; '.join(data.get('sources') or []),
          'qualified_for_pt':code in shortlist})
    return sorted(result,key=lambda r:(r['google_count'] is None,r['google_count'] if r['google_count'] is not None else 10**9,r['code']))

def publish(camp):
    with LOCK:
        if camp['stage2']!='complete':raise ValueError('Stage 2 must complete before final recommendations')
        if any(camp['pt'].get(c,{}).get('status')!='checked' for c in camp['shortlist']):
            raise ValueError('A Psychology Today result is missing')
        if not camp['published']:
            for c in camp['shortlist']:
                DB['history'].append({'code':c,'date':today().isoformat(),'origin':'campaign '+camp['id']})
            camp['published']=True;persist()
        return ranked(camp)

HTML='''<!DOCTYPE html><html lang="en"><meta charset="UTF-8"><title>Ontario Therapy Finder — 2 separate stages</title>
<style>body{font:16px system-ui;max-width:1140px;margin:25px auto;padding:0 18px;color:#263542}button{padding:12px;margin:4px;border:0;border-radius:5px;background:#235e84;color:white;cursor:pointer}input{padding:7px}section{border:1px solid #d7dee7;padding:18px;margin:14px 0;border-radius:9px}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #ddd;padding:8px;text-align:left}small{color:#555}#status{white-space:pre-wrap}</style>
<h1>Ontario Therapy Finder</h1><p>Google Maps screening and current Psychology Today checks run separately. Postal areas returned in the past 90 days are excluded from new campaigns.</p>
<section><h2>Stage 1 — province-wide Google Maps screening</h2><p>Searches 60 more eligible Ontario FSAs per batch, saving progress. You can repeat the batch to examine the entire province. No PT requests occur during this stage.</p><button id="g" onclick="act('/api/stage1')">Scan next 60 postal areas</button><button onclick="act('/api/stop')">Stop</button><button onclick="location.href='/export-google.csv'">Export Google shortlist</button></section>
<section><h2>Stage 2 — this week's Psychology Today check</h2><p>Checks current PT counts only for the verified low-Google-competition shortlist from Stage 1. Previous campaigns' results stay excluded; this campaign can complete both stages.</p><button id="p" onclick="act('/api/stage2')">Check Psychology Today now</button><button onclick="act('/api/publish')">Finalize this campaign and record 90-day exclusions</button><button onclick="location.href='/export-final.csv'">Export final comparison</button></section>
<section><div id="status">Loading...</div><div id="summary"></div></section><section><h2>Google results — every area checked</h2><table><thead><tr><th>Postal area</th><th>Observed listings within 5 km</th><th>Coverage</th><th>PT candidate?</th></tr></thead><tbody id="allrows"></tbody></table></section><section><h2>Low-competition shortlist for the separate PT run</h2><table><thead><tr><th>Postal area</th><th>Google listings within 5 km</th><th>PT count this week</th><th>Sources</th></tr></thead><tbody id="rows"></tbody></table></section>
<script>async function req(p,post){const r=await fetch(p,post?{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}:{});const j=await r.json();if(!r.ok||j.error)throw Error(j.error||r.status);return j}async function act(p){try{const j=await req(p,true);document.getElementById('status').textContent=j.message||'Started';refresh()}catch(e){alert(e.message)}}async function refresh(){try{const j=await req('/api/state');document.getElementById('status').textContent=j.status.message;document.getElementById('summary').textContent=j.summary;document.getElementById('g').disabled=j.status.state==='running';document.getElementById('p').disabled=j.status.state==='running';const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));document.getElementById('allrows').innerHTML=j.google_rows.map(r=>`<tr><td>${esc(r.code)}</td><td>${r.google_count===null?'—':r.google_count}</td><td>${esc(r.google_coverage||r.google_error||r.google_status)}</td><td>${r.qualified_for_pt?'Yes':'No / incomplete'}</td></tr>`).join('');document.getElementById('rows').innerHTML=j.rows.map(r=>`<tr><td>${esc(r.code)}</td><td>${r.google_count}</td><td>${esc(r.pt_display||r.pt_status)}</td><td><a target="_blank" href="${esc(r.pt_url)}">PT</a> · <a target="_blank" href="${esc(r.google_sources[0]||'#')}">Maps</a></td></tr>`).join('')}catch(e){document.getElementById('status').textContent=e.message}}refresh();setInterval(refresh,3000)</script></html>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def answer(self,content,status=200,mime='application/json; charset=utf-8',filename=None):
        raw=content.encode('utf-8-sig') if mime.startswith('text/csv') else (content if isinstance(content,bytes) else content.encode('utf8'))
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store')
        if filename:self.send_header('Content-Disposition','attachment; filename="'+filename+'"')
        self.end_headers();self.wfile.write(raw)
    def j(self,body,status=200):self.answer(json.dumps(body,ensure_ascii=False),status)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/':return self.answer(HTML,200,'text/html; charset=utf-8')
        with LOCK:
            camp=current()
            rows=ranked(camp) if camp else []
            summary=(f'{len(camp["maps"])} FSAs checked; {len(camp["shortlist"])} qualified low-competition areas; '
                     f'{len(camp["pt"])} PT observations; {len(camp["queue"])-len(camp["maps"])} remaining; '
                     f'{len(camp["excluded_previous_90_days"])} past recommendations excluded.' if camp else 'New campaign ready')
            if path=='/api/state':return self.j({'status':DB['status'],'summary':summary,'rows':rows,'google_rows':google_report(camp) if camp else [],'history':DB['history'],'campaign':camp and camp['id']})
            if path in ('/export-google.csv','/export-final.csv'):
                if not camp:return self.j({'error':'No campaign started'},400)
                if path=='/export-final.csv' and not camp.get('published'):return self.j({'error':'Complete Stage 2 and finalize campaign first'},409)
                buf=io.StringIO();w=csv.writer(buf)
                w.writerow(['FSA','Google observed unique therapy locations within 5km','Google coverage','Google checked at','PT displayed count','PT status','PT checked at','Google source','PT source'])
                if path=='/export-google.csv':
                    for r in google_report(camp):
                        w.writerow([r['code'],r['google_count'],r['google_coverage'],r['checked_at'],'','not_requested','','; '+r['source'] if r['source'] else '',quickscan.pt_url(r['code'])])
                else:
                    for r in rows:
                        w.writerow([r['code'],r['google_count'],r['google_coverage'],r['google_checked_at'],r['pt_display'],r['pt_status'],r['pt_checked_at'],'; '.join(r['google_sources']),r['pt_url']])
                return self.answer(buf.getvalue(),200,'text/csv; charset=utf-8','ontario_google_shortlist.csv' if path=='/export-google.csv' else 'ontario_final_comparison.csv')
        return self.j({'error':'Unknown path'},404)
    def do_POST(self):
        global THREAD
        path=urlparse(self.path).path
        if path=='/api/stop':HALT.set();return self.j({'message':'Stop requested. Saved work remains.'})
        with LOCK:
            if THREAD and THREAD.is_alive():return self.j({'error':'A scan is already running'},409)
            if path=='/api/publish':
                try:publish(current());return self.j({'message':'Finalized, with 90-day nonrepeat ledger updated.'})
                except (ValueError,TypeError,AttributeError) as ex:return self.j({'error':str(ex)},409)
            if path=='/api/stage1':fn=stage1
            elif path=='/api/stage2':fn=stage2
            else:return self.j({'error':'Unknown command'},404)
            HALT.clear();THREAD=threading.Thread(target=fn,daemon=True);THREAD.start()
            return self.j({'message':'Stage launched. Updates are saved after every postal area.'})

def run():
    try:
        n=refresh_official_pool()
        print(f'{n} officially sourced populated Ontario postal areas available for Stage 1.',flush=True)
    except Exception as exc:raise RuntimeError('Ontario source pool unavailable: '+str(exc)) from exc
    app=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    url=f'http://127.0.0.1:{app.server_port}/'
    print('Two-stage Ontario screen: '+url,flush=True)
    webbrowser.open(url)
    try:app.serve_forever()
    except KeyboardInterrupt:pass
    finally:app.server_close()

if __name__=='__main__':run()
