import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from datetime import date, timedelta
import staged

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.prev=(staged.STATE,staged.DB,staged.THREAD,staged.POOL)
        staged.STATE=Path(self.tmp.name)/'state.json'
        staged.POOL=Path(self.tmp.name)/'pool.json'
        pool=staged.load_pool(self.prev[3]);staged.POOL.write_text(json.dumps({'areas':list(pool.values())}))
        staged.DB=staged.fresh_state();staged.THREAD=None;staged.HALT.clear()
    def tearDown(self):
        staged.STATE,staged.DB,staged.THREAD,staged.POOL=self.prev
        staged.HALT.clear();self.tmp.cleanup()
    def test_90_day_history_and_campaign_continuation(self):
        day=date(2026,11,21)
        hist=[{'code':'K1B','date':'2026-11-20'}, {'code':'K1C','date':'2026-08-21'}]
        self.assertEqual(staged.excluded(hist,day),{'K1B'})
        camp=staged.start_campaign(staged.load_pool(),day)
        self.assertNotIn('N1T',camp['queue'])
        self.assertIn('K1B',camp['queue'])
        self.assertIn('P2A',camp['queue'])
    def test_province_pool_is_100_plus_not_two(self):
        pool=staged.load_pool()
        self.assertGreaterEqual(len(pool),100)
        self.assertTrue(all(12000<=row['population_2021'] for row in pool.values()))
        self.assertFalse(any(c in pool for c in ('L8S','L9H','L9K')))
    def test_stages_separate_and_history_marks_publication_not_scans(self):
        pool=staged.load_pool()
        def google(areas,centers,root,callback,stop,max_queries):
            for code,city in areas:
                callback(code,{'status':'completed','google_count':3,'coverage':'observed_complete_feeds',
                               'sources':['https://www.google.com/maps/'],'checked_at':staged.now(),'missing_coordinates':0})
        with patch('google_auto.google_screen',side_effect=google),patch.object(staged,'load_pool',return_value=pool),patch.object(staged.HALT,'wait',return_value=False),patch.object(staged.quickscan,'get_pt_summary_with_browser_fallback',return_value={'display':'10+','lower_bound':10,'rounded_lower_bound':True}) as pt:
            staged.stage1(batch=35)
            camp=staged.current()
            self.assertEqual(len(camp['maps']),35)
            self.assertEqual(len(camp['shortlist']),35)
            self.assertEqual(camp['stage2'],'not_started')
            self.assertEqual(pt.call_count,0)
            self.assertNotIn(camp['shortlist'][0],staged.excluded(staged.DB['history']))
            staged.stage2()
            self.assertEqual(pt.call_count,35)
            self.assertEqual(camp['stage2'],'complete')
            rows=staged.publish(camp)
            self.assertEqual(len(rows),35)
            self.assertTrue(camp['published'])
            self.assertIn(camp['shortlist'][0],staged.excluded(staged.DB['history']))
            another=staged.start_campaign(pool)
            self.assertFalse(set(camp['shortlist'])&set(another['queue']))
            before=len(staged.DB['history']);staged.publish(camp)
            self.assertEqual(len(staged.DB['history']),before)
    def test_unresolved_and_blocked_never_enter_shortlist(self):
        camp=staged.start_campaign(staged.load_pool())
        codes=camp['queue'][:4]
        camp['maps']={codes[0]:{'status':'completed','google_count':0,'coverage':'unresolved_location_links'},
                      codes[1]:{'status':'completed','google_count':0,'coverage':'capped_lower_bound'},
                      codes[2]:{'status':'blocked','error':'captcha'},
                      codes[3]:{'status':'completed','google_count':4,'coverage':'observed_complete_feeds','missing_coordinates':0}}
        self.assertEqual(staged.eligible_shortlist(camp),[codes[3]])
    def test_stage2_requires_google_and_final_export_requires_pt(self):
        camp=staged.start_campaign(staged.load_pool());staged.DB['campaigns']=[camp]
        staged.stage2();self.assertEqual(staged.DB['status']['state'],'error')
        with self.assertRaises(ValueError):staged.publish(camp)
    def test_stage_resume_does_not_repeat_successful_google_observations(self):
        pool=staged.load_pool();record=[]
        def google(areas,centers,root,callback,stop,max_queries):
            record.extend([a[0] for a in areas]);
            for code,_ in areas:callback(code,{'status':'completed','google_count':4,'coverage':'observed_complete_feeds','missing_coordinates':0,'sources':[]})
        with patch('google_auto.google_screen',side_effect=google),patch.object(staged,'load_pool',return_value=pool):
            staged.stage1(batch=20);staged.stage1(batch=20)
            self.assertEqual(len(record),40)
            self.assertEqual(len(set(record)),40)
            self.assertEqual(len(staged.current()['shortlist']),40)

if __name__=='__main__':unittest.main()

class PersistenceContractTests(unittest.TestCase):
    def test_90day_ledger_survives_program_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            current_state,db=staged.STATE,staged.DB
            try:
                staged.STATE=Path(tmp)/'user_data'/'staged_results.json'
                staged.DB=staged.fresh_state()
                staged.DB['history'].append({'code':'P1H','date':staged.today().isoformat(),'origin':'previous published campaign'})
                staged.persist()
                staged.DB=staged.load()
                self.assertIn('P1H',staged.excluded(staged.DB['history']))
            finally:
                staged.STATE,staged.DB=current_state,db
