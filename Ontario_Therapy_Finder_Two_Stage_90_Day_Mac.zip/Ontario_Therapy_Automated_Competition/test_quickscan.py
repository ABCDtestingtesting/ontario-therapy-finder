import csv
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
import quickscan as app


def html_for(code='N4G',count='30+'):
    return f'''<!doctype html><html><title>Find Therapists</title><body>
      <h1>Therapists in {code}</h1>
      <article><a href="/ca/therapists/therapist-tillsonburg-on/123456">Therapist</a></article>
      <h4>Number of Counsellors in {code}</h4><strong>{count}</strong>
    </body></html>'''

class FakeResponse:
    status=200
    url='https://www.psychologytoday.com/ca/therapists/n4g'
    def __init__(self,data):self.data=data
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,size):return self.data

class TestQuickScan(unittest.TestCase):
    def test_real_markup_count_lower_bound(self):
        out=app.parse_pt(html_for(),'N4G')
        self.assertEqual(out['display'],'30+')
        self.assertEqual(out['lower_bound'],30)
        self.assertTrue(out['rounded_lower_bound'])
        self.assertEqual(out['visible_profile_links'],1)
    def test_exact_count_remains_exact(self):
        out=app.parse_pt(html_for(count='4'),'N4G')
        self.assertEqual(out['display'],'4')
        self.assertFalse(out['rounded_lower_bound'])
    def test_block_page_not_zero(self):
        with self.assertRaises(app.PTAccessError) as context:
            app.parse_pt('<body>Verify you are human</body>','N4G')
        self.assertTrue(context.exception.blocked)
    def test_unrelated_directory_rejected(self):
        with self.assertRaises(app.PTAccessError):
            app.parse_pt(html_for('L7A'), 'N4G')
    def test_no_directory_total_never_zero(self):
        with self.assertRaises(app.PTAccessError):
            app.parse_pt(html_for().split('<h4>')[0]+'</body></html>','N4G')
    def test_rounded_count_parse(self):
        self.assertEqual(app.normalize_count('20+'),{'display':'20+','lower_bound':20,'rounded_lower_bound':True})
        self.assertIsNone(app.normalize_count(''))
        with self.assertRaises(ValueError):app.normalize_count('lots')
    def test_rejected_redirection(self):
        fake=FakeResponse(html_for().encode())
        fake.url='https://www.psychologytoday.com/ca/therapists/l7a'
        with patch.object(app,'urlopen',return_value=fake):
            with self.assertRaises(app.PTAccessError):app.get_pt_summary('N4G')
    def test_pt_status_http429(self):
        err=HTTPError(app.pt_url('N4G'),429,'Too many requests',{},None)
        with patch.object(app,'urlopen',side_effect=err):
            with self.assertRaises(app.PTAccessError) as context:
                app.get_pt_summary('N4G')
        self.assertTrue(context.exception.blocked)
    def test_successful_first_page_network_parsed(self):
        with patch.object(app,'urlopen',return_value=FakeResponse(html_for().encode())):
            self.assertEqual(app.get_pt_summary('N4G')['display'],'30+')
    def test_hamilton_excluded(self):
        self.assertIn('L9H',app.HAMILTON)
        self.assertNotIn('N4G',app.HAMILTON)
    def test_no_automated_google_grids_or_expensive_dependency(self):
        self.assertNotIn('playwright',app.__file__)
        self.assertEqual(app.SLEEP_BETWEEN_REQUESTS_SECONDS,5)
        self.assertTrue(all(app.CODES.fullmatch(c) for c,_ in app.STARTERS))
    def test_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            old=app.STATE;oldDB=app.DB
            try:
                app.STATE=Path(d)/'research_data'/'results.json'
                app.DB=app.load();app.DB['areas']['N4G']['pt_count']=app.normalize_count('30+')
                app.save_locked()
                a=app.load();self.assertEqual(a['areas']['N4G']['pt_count']['display'],'30+')
            finally:app.STATE=old;app.DB=oldDB

if __name__=='__main__':unittest.main()

class UpperBoundCounts(unittest.TestCase):
    def test_under_ten_is_preserved_as_upper_bound(self):
        data=html_for(count='&lt; 10')
        value=app.parse_pt(data,'N4G')
        self.assertEqual(value['display'],'< 10')
        self.assertIsNone(value['lower_bound'])
        self.assertEqual(value['upper_bound_exclusive'],10)
