import json,threading,io,csv,unittest,tempfile
from pathlib import Path
from urllib.request import urlopen,Request
from urllib.error import HTTPError
from unittest.mock import patch
from http.server import ThreadingHTTPServer
import staged

class HTTPWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.original=(staged.STATE,staged.DB,staged.THREAD)
        staged.STATE=Path(self.tmp.name)/'saved.json';staged.DB=staged.fresh_state();staged.THREAD=None
        self.server=ThreadingHTTPServer(('127.0.0.1',0),staged.Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.server.server_port)
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=5)
        staged.STATE,staged.DB,staged.THREAD=self.original
        self.tmp.cleanup()
    def test_empty_status_and_export_require_campaign(self):
        with urlopen(self.url+'/api/state') as r:s=json.load(r)
        self.assertEqual(s['rows'],[])
        with self.assertRaises(HTTPError) as ctx:urlopen(self.url+'/export-final.csv')
        self.assertEqual(ctx.exception.code,400)
    def test_google_export_separate_and_final_requires_pt(self):
        pool=staged.load_pool();camp=staged.start_campaign(pool)
        c=camp['queue'][0]
        camp['maps'][c]={'status':'completed','coverage':'observed_complete_feeds','google_count':3,
                        'checked_at':staged.now(),'sources':['https://www.google.com/maps/']}
        camp['shortlist']=[c];staged.DB['campaigns']=[camp]
        with urlopen(self.url+'/export-google.csv') as r:rows=list(csv.DictReader(io.StringIO(r.read().decode('utf-8-sig'))))
        self.assertEqual(len(rows),1)
        with self.assertRaises(HTTPError) as ctx:urlopen(self.url+'/export-final.csv')
        self.assertEqual(ctx.exception.code,409)
        camp['pt'][c]={'status':'checked','checked_at':staged.now(),'count':{'display':'10+','lower_bound':10}}
        camp['stage2']='complete';staged.publish(camp)
        with urlopen(self.url+'/export-final.csv') as r:rows=list(csv.DictReader(io.StringIO(r.read().decode('utf-8-sig'))))
        self.assertEqual(rows[0]['PT displayed count'],'10+')
        self.assertIn(c,staged.excluded(staged.DB['history']))

if __name__=='__main__':unittest.main()

class GoogleReportTests(unittest.TestCase):
    def test_maps_export_contains_every_checked_code_even_without_pt_shortlist(self):
        pool=staged.load_pool()
        camp=staged.start_campaign(pool)
        one,two=camp['queue'][:2]
        camp['maps']={one:{'status':'completed','google_count':4,'coverage':'observed_complete_feeds',
                            'checked_at':staged.now(),'sources':['https://www.google.com/maps/']},
                      two:{'status':'completed','google_count':90,'coverage':'capped_lower_bound',
                            'checked_at':staged.now(),'sources':['https://www.google.com/maps/']}}
        camp['shortlist']=[one]
        rows=staged.google_report(camp)
        self.assertEqual(len(rows),2)
        self.assertEqual([r['code'] for r in rows],[one,two])
        self.assertEqual([r['qualified_for_pt'] for r in rows],[True,False])

    def test_history_is_exclusion_for_next_campaign_not_stage2_of_same_campaign(self):
        c=staged.start_campaign(staged.load_pool())
        code=c['queue'][0];c['shortlist']=[code]
        c['maps'][code]={'status':'completed','google_count':1,'coverage':'observed_complete_feeds'}
        self.assertNotIn(code,staged.excluded(staged.DB['history']))
        self.assertIn(code,c['shortlist'])
